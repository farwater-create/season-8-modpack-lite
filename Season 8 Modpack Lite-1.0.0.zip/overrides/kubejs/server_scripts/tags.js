// priority: 1

onEvent("item.tags", (event) => {

});
